-- MySQL dump 10.13  Distrib 5.7.33, for linux-glibc2.12 (x86_64)
--
-- Host: 127.0.0.1    Database: library_system
-- ------------------------------------------------------
-- Server version	5.7.33-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `book_copy`
--

DROP TABLE IF EXISTS `book_copy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `book_copy` (
  `book_copyid` bigint(20) NOT NULL AUTO_INCREMENT,
  `adminid` bigint(20) DEFAULT NULL,
  `borrower` varchar(255) DEFAULT NULL,
  `isbn` varchar(255) DEFAULT NULL,
  `last_rent_date` datetime(6) DEFAULT NULL,
  `last_reservation_date` datetime(6) DEFAULT NULL,
  `last_return_date` datetime(6) DEFAULT NULL,
  `libraryid` bigint(20) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `unique_book_mark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`book_copyid`),
  UNIQUE KEY `UK_jkn0k14d0ueofy9c5if82851x` (`unique_book_mark`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book_copy`
--

LOCK TABLES `book_copy` WRITE;
/*!40000 ALTER TABLE `book_copy` DISABLE KEYS */;
INSERT INTO `book_copy` VALUES (1,1,'19302010021','1234567891','2021-05-23 23:56:08.218000','2021-05-23 23:44:52.038000','2021-05-24 12:03:37.135000',1,'已损坏','1234567891-1'),(2,1,'19302010021','1234567891','2021-05-24 12:03:08.879000','2021-05-24 11:56:39.489000','2021-05-24 12:03:37.208000',1,'已损坏','1234567891-2'),(3,1,'19302010021','1234567891','2021-05-24 12:03:20.542000','2021-05-24 11:53:00.718000','2021-05-24 12:03:37.271000',1,'已丢失','1234567891-3'),(4,1,'19302010021','1234567891','2021-06-15 22:33:15.999000','2021-06-15 22:33:36.664000','2021-06-15 22:33:25.781000',3,'可用（在架上）','1234567891-4'),(5,0,NULL,'1234567891',NULL,'2021-06-15 22:35:11.550000',NULL,3,'可用（在架上）','1234567891-5'),(6,1,'19302010021','9787111544937','2021-06-16 15:38:29.003000','2021-06-15 22:37:01.069000','2021-06-16 15:38:56.923000',3,'可用（在架上）','9787111544937-1'),(7,0,NULL,'9787111544937',NULL,'2021-05-24 11:56:33.714000',NULL,3,'可用（在架上）','9787111544937-2'),(8,0,NULL,'9787111544937',NULL,'2021-05-24 11:56:34.961000',NULL,3,'可用（在架上）','9787111544937-3'),(9,0,NULL,'9787111544937',NULL,NULL,NULL,3,'可用（在架上）','9787111544937-4'),(10,1,'20212010040','1234567891','2021-05-24 20:27:40.258000','2021-05-24 20:26:48.273000','2021-05-24 20:28:57.472000',1,'已损坏','1234567891-6'),(11,1,'19302010021','1234567891','2021-06-15 22:36:40.599000','2021-06-15 22:24:00.337000','2021-06-16 11:55:32.265000',2,'可用（在架上）','1234567891-7'),(12,1,'18300120031','1234567891','2021-06-15 22:31:19.017000','2021-06-17 00:57:54.997000','2021-06-15 22:33:29.554000',1,'可用（在架上）','1234567891-8'),(13,1,'19302010021','9787121123320','2021-06-16 11:23:39.746000',NULL,'2021-06-16 11:24:25.422000',2,'可用（在架上）','9787121123320-1'),(14,1,'19302010021','9787121123320','2021-06-16 11:23:39.767000',NULL,'2021-06-16 11:24:25.444000',2,'已损坏','9787121123320-2'),(15,1,'19302010021','9787121123320','2021-06-16 11:23:39.777000',NULL,'2021-06-16 11:24:25.496000',2,'已丢失','9787121123320-3'),(16,1,'19302010021','9787121123320','2021-06-16 11:53:47.958000',NULL,'2021-06-16 11:54:25.900000',2,'已损坏','9787121123320-4'),(17,1,'19302010021','9787121123320','2021-06-16 11:53:47.980000',NULL,'2021-06-16 11:54:26.019000',2,'已丢失','9787121123320-5'),(18,1,'19302010021','9787121123320','2021-06-16 11:50:52.823000',NULL,'2021-06-16 11:53:00.180000',2,'可用（在架上）','9787121123320-6'),(19,0,NULL,'9787121123320',NULL,NULL,NULL,2,'可用（在架上）','9787121123320-7'),(20,0,NULL,'9787115281487',NULL,NULL,NULL,1,'可用（在架上）','9787115281487-1'),(21,0,NULL,'9787115281487',NULL,NULL,NULL,1,'可用（在架上）','9787115281487-2'),(22,0,NULL,'9787115281487',NULL,NULL,NULL,1,'可用（在架上）','9787115281487-3'),(23,0,NULL,'9787115281487',NULL,NULL,NULL,1,'可用（在架上）','9787115281487-4'),(24,0,NULL,'9787115281487',NULL,NULL,NULL,1,'可用（在架上）','9787115281487-5'),(25,0,NULL,'9787115281487',NULL,NULL,NULL,1,'可用（在架上）','9787115281487-6'),(26,0,NULL,'9787115281487',NULL,NULL,NULL,1,'可用（在架上）','9787115281487-7'),(27,0,NULL,'9787115281487',NULL,NULL,NULL,1,'可用（在架上）','9787115281487-8'),(28,0,NULL,'9787115281487',NULL,NULL,NULL,1,'可用（在架上）','9787115281487-9'),(29,0,NULL,'9787115281487',NULL,NULL,NULL,1,'可用（在架上）','9787115281487-10'),(30,1,'19302010021','9780134481265','2021-06-25 18:22:09.306000',NULL,'2021-06-25 18:22:40.057000',1,'可用（在架上）','9780134481265-1'),(31,1,'19302010021','9780134481265','2021-06-25 18:22:09.334000',NULL,'2021-06-25 18:22:40.139000',1,'已丢失','9780134481265-2'),(32,0,NULL,'9780134481265',NULL,NULL,NULL,1,'可用（在架上）','9780134481265-3'),(33,0,NULL,'9780134481265',NULL,NULL,NULL,1,'可用（在架上）','9780134481265-4'),(34,0,NULL,'9780134481265',NULL,NULL,NULL,1,'可用（在架上）','9780134481265-5'),(35,0,NULL,'9780134481265',NULL,NULL,NULL,1,'可用（在架上）','9780134481265-6'),(36,0,NULL,'9780134481265',NULL,NULL,NULL,1,'可用（在架上）','9780134481265-7'),(37,0,NULL,'9780134481265',NULL,NULL,NULL,1,'可用（在架上）','9780134481265-8'),(38,0,NULL,'9780134481265',NULL,NULL,NULL,1,'可用（在架上）','9780134481265-9'),(39,0,NULL,'9780134481265',NULL,NULL,NULL,1,'可用（在架上）','9780134481265-10'),(40,1,'20212010040','9787111544937','2021-06-25 21:32:18.793000','2021-06-25 21:32:01.231000','2021-06-25 21:37:52.208000',1,'可用（在架上）','9787111544937-5'),(41,0,NULL,'9787111544937',NULL,'2021-06-25 21:32:02.846000',NULL,1,'可用（在架上）','9787111544937-6'),(42,1,'20212010040','9787111544937','2021-06-25 21:32:45.855000',NULL,'2021-06-25 21:33:02.689000',1,'已损坏','9787111544937-7'),(43,1,'20212010040','9787111544937','2021-06-25 21:32:45.867000',NULL,'2021-06-25 21:33:02.744000',1,'已丢失','9787111544937-8');
/*!40000 ALTER TABLE `book_copy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `book_type`
--

DROP TABLE IF EXISTS `book_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `book_type` (
  `bookid` bigint(20) NOT NULL AUTO_INCREMENT,
  `author` varchar(255) DEFAULT NULL,
  `description` text,
  `image_path` varchar(255) DEFAULT NULL,
  `image_path_to_front_end` varchar(255) DEFAULT NULL,
  `isbn` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` bigint(20) DEFAULT NULL,
  `publication_date` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`bookid`),
  UNIQUE KEY `UK_2jauf35cnetu5tgh2gtfreetl` (`isbn`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book_type`
--

LOCK TABLES `book_type` WRITE;
/*!40000 ALTER TABLE `book_type` DISABLE KEYS */;
INSERT INTO `book_type` VALUES (1,'Ian Sommerville','《软件工程（原书第10版）》是机械工业出版社出版的图书，该书作者是(英)Ian Sommerville.','/usr/local/bookcovers/3585cf7b-4e39-471b-85e2-06e818c8de53.jpg','/image/bookcover/3585cf7b-4e39-471b-85e2-06e818c8de53.jpg','1234567891','软件工程',5000,'2010-01-01 08:00:00.000000'),(2,'	（美）兰德尔·E.布莱恩特（Randal E.Bryant）','本书从程序员的视角详细阐述计算机系统的本质概念，并展示这些概念如何实实在在地影响应用程序的正确性、性能和实用性。全书共12章，主要包括信息的表示和处理、程序的机器级表示、处理器体系结构、优化程序性能、存储器层次结构、链接、异常控制流、虚拟存储器、系统级I/O、网络编程、并发编程等内容。书中提供了大量的例子和练习题，并给出部分答案，有助于读者加深对正文所述概念和知识的理解。','/usr/local/bookcovers/c8b46593-67c2-44e7-9aed-83bd2b5de9c0.jpeg','/image/bookcover/c8b46593-67c2-44e7-9aed-83bd2b5de9c0.jpeg','9787111544937','深入理解计算机系统',13900,'2016-11-01 08:00:00.000000'),(3,'[巴西]卢西亚诺·拉马略(Luciano Ramalho)','流畅的Python 致力于帮助Python开发人员挖掘这门语言及相关程序库的优质特性，避免重复劳动，同时写出简洁、流畅、易读、易维护，并且具有地道Python风格的代码。流畅的Python 尤其深入探讨了Python语言的用法，涵盖数据结构、Python风格的对象、并行与并发，以及元编程等不同的方面。','/usr/local/bookcovers/cc1eb29e-16a8-4d57-9641-74afa1592d1c.jpeg','/image/bookcover/cc1eb29e-16a8-4d57-9641-74afa1592d1c.jpeg','9787115454157','流畅的python',13900,'2017-04-01 08:00:00.000000'),(4,'[美] Scott Meyers','在国际上，本书所引起的反响，波及整个计算机技术的出版领域，余音至今未绝。几乎在所有C++书籍的推荐名单上，这本书都会位于前三名。\n\n作者高超的技术把握力、独特的视角、诙谐轻松的写作风格、独具匠心的内容组织，都受到极大的推崇和仿效。\n\n这本书不是读完一遍就可以束之高阁的快餐读物，也不是用以解决手边问题的参考手册，而是需要你去反复阅读体会的，C++是真正程序员的语言，背后有着精深的思想与无以伦比的表达能力，这使得它具有类似宗教般的魅力。','/usr/local/bookcovers/01265b16-58ca-44e7-9969-b84a625a88d4.jpg','/image/bookcover/01265b16-58ca-44e7-9969-b84a625a88d4.jpg','9787121123320','Effective C++ 改善程序与设计的55个具体做法',6500,'2011-01-01 08:00:00.000000'),(5,'David Gourley / Brian Totty','超文本传输协议（Hypertext Transfer Protocol，HTTP）是在万维网上进行通信时所使用的协议方案。HTTP有很多应用，但最著名的是用于web浏览器和web服务器之间的双工通信。\n\nHTTP起初是一个简单的协议，因此你可能会认为关于这个协议没有太多好说的。但现在，你手上拿着的是却一本两磅重 的书。如果你对我们怎么会写出一本650页 的关于HTTP的书感到奇怪的话，可以去看一下目录。本书不仅仅是一本HTTP首部的参考手册；它是一本名副其实的web结构圣经。\n\n本书中，我们尝试着将HTTP中一些互相关联且常被误解的规则梳理清楚，并编写了一系列基于各种主题的章节，对HTTP各方面的特性进行了介绍。纵观全书，我们对HTTP“为什么”这样做进行了详细的解释，而不仅仅停留在它是“怎么做”的。而且，为了节省大家寻找参考文献的时间，我们还对很多HTTP应用程序正常工作所必须的、重要的非HTTP技术进行了介绍。在组织得便于使用的附录中，可以找到按照字母排序的首部参考（这些首部构成了最常见的HTTP文本的基础）。我们希望这种概念性的设计有助于读者对HTTP的使用。\n\n本书是为所有希望理解HTTP以及Web底层结构的人编写的。软硬件工程师也可以将本书作为HTTP及相关web技术的条理清楚的参考书使用。系统架构师和网络管理员可以通过本书更好地了解如何设计、实现并管理复杂的网络架构。性能工程师和分析人员可以从高速缓存和性能优化的相关章节中获益。市场营销和咨询专家可以通过概念的介绍更好地理解web技术的前景。\n\n本书对一些常见的误解进行了说明，推荐了“各种使用诀窍”，提供了便捷的参考资料，并且对枯燥且令人费解的标准规范进行了可读性很强的介绍。在这本书里，我们对Web正常工作所必须且互相关联的技术进行了详细的介绍。\n\n本书是很多对因特网技术充满热情的人经过大量工作写成的。希望对你有所帮助。','/usr/local/bookcovers/45a29ea4-03c2-42eb-8f51-321e4f618689.jpg','/image/bookcover/45a29ea4-03c2-42eb-8f51-321e4f618689.jpg','9787115281487','HTTP权威指南',10900,'2012-09-01 08:00:00.000000'),(7,' Eric A. Meyer / Estelle Weyl','如果你是网页设计师或应用开发者，对复杂的页面样式、改进可访问性以及节省时间和精力感兴趣，决不能错过这本书。这一修订版全面阐述了 CSS 的实现方式，还深入分析了最新的 CSS 规范。\n\nCSS 是一门不断发展的语言，用于描述 Web 内容在屏幕、打印机、语音合成器、屏幕阅读器和聊天窗口上的表现。各种物联网设备，不论屏幕尺寸大小，只要有浏览器，就用得到 CSS，这其中包括手机、计算机、视频游戏、电视、手表、自助服务终端和汽车控制台。本书两位作者 Eric Meyer 和 Estelle Weyl 向您展示了如何通过布局、过渡和动画、边框、背景、文本属性，以及许多其他工具和技术来改善用户体验、加快开发速度、避免潜在的错误，并为您的应用程序增光添色。','/usr/local/bookcovers/8e57a768-f76c-45d4-83ab-eec75fc6954d.jpg','/image/bookcover/8e57a768-f76c-45d4-83ab-eec75fc6954d.jpg','9787519826598','CSS权威指南（第四版）',19800,'2019-04-01 08:00:00.000000'),(8,'null','For courses in Web Programming and Design: Numerous Mark-up / Scripting Languages, as part of the CS1 course sequence.   Master the fundamentals of web development                                                                                                                                                 Fundamentals of Web Development , 2nd Edition guides readers through the creation of enterprise-quality websites using current development frameworks. Written by a leading teacher in the field and designed for serious programmers, this book is as valuable to developers as a dev bootcamp. Its practical approach and comprehensive insight into the practice of web development covers HTML5, CSS3, Javascript, and the LAMP stack (that is, Linux, Apache, MySQL, and PHP), jQuery, XML, WordPress, Bootstrap, and a variety of third-party APIs that include Facebook, Twitter, Google, and Bing Maps. Coverage also includes the required ACM web development topics, aligned with real-world web development best practices. The 2nd Edition faithfully covers the most vital trends and innovations in the field since 2013, while continuing to provide a thorough and comprehensive overview.        ','/usr/local/bookcovers/704daee2-c50f-436b-ba8a-c25b0a5fa5d7.jpg','/image/bookcover/704daee2-c50f-436b-ba8a-c25b0a5fa5d7.jpg','9780134481265','Fundamentals of Web Development (2nd Edition)',11451400,'2017-01-01 08:00:00.000000'),(9,'普拉达 (Stephen Prata)','《C Primer Plus（第6版）中文版》详细讲解了C语言的基本概念和编程技巧。\n\n《C Primer Plus（第6版）中文版》共17章。第1、2章介绍了C语言编程的预备知识。第3~15章详细讲解了C语言的相关知识，包括数据类型、格式化输入/输出、运算符、表达式、语句、循环、字符输入和输出、函数、数组和指针、字符和字符串函数、内存管理、文件输入输出、结构、位操作等。第16章、17章介绍C预处理器、C库和高级数据表示。本书以完整的程序为例，讲解C语言的知识要点和注意事项。每章末设计了大量复习题和编程练习，帮助读者巩固所学知识和提高实际编程能力。附录给出了各章复习题的参考答案和丰富的参考资料。\n\n《C Primer Plus（第6版）中文版》可作为C语言的教材，适用于需要系统学习C语言的初学者，也适用于巩固C语言知识或希望进一步提高编程技术的程序员。','/usr/local/bookcovers/15cecbee-cb8b-4ab6-a5f1-921ebb6191ec.jpg','/image/bookcover/15cecbee-cb8b-4ab6-a5f1-921ebb6191ec.jpg','9787115390592','C Primer Plus（第6版）中文版',8901,'2016-04-01 08:00:00.000000');
/*!40000 ALTER TABLE `book_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `borrow`
--

DROP TABLE IF EXISTS `borrow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `borrow` (
  `borrowid` bigint(20) NOT NULL AUTO_INCREMENT,
  `borrow_date` datetime(6) DEFAULT NULL,
  `deadline` datetime(6) DEFAULT NULL,
  `unique_book_mark` varchar(255) DEFAULT NULL,
  `userid` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`borrowid`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `borrow`
--

LOCK TABLES `borrow` WRITE;
/*!40000 ALTER TABLE `borrow` DISABLE KEYS */;
/*!40000 ALTER TABLE `borrow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `borrow_record`
--

DROP TABLE IF EXISTS `borrow_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `borrow_record` (
  `borrow_recordid` bigint(20) NOT NULL AUTO_INCREMENT,
  `admin` varchar(255) DEFAULT NULL,
  `libraryid` bigint(20) NOT NULL,
  `time` datetime(6) DEFAULT NULL,
  `unique_book_mark` varchar(255) DEFAULT NULL,
  `userid` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`borrow_recordid`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `borrow_record`
--

LOCK TABLES `borrow_record` WRITE;
/*!40000 ALTER TABLE `borrow_record` DISABLE KEYS */;
INSERT INTO `borrow_record` VALUES (1,'admin',1,'2021-05-23 23:56:08.218000','1234567891-1',6),(2,'admin',1,'2021-05-24 12:03:08.879000','1234567891-2',6),(3,'admin',1,'2021-05-24 12:03:20.542000','1234567891-3',6),(4,'admin',1,'2021-05-24 20:27:40.258000','1234567891-6',15),(5,'admin',1,'2021-05-24 20:27:40.335000','1234567891-7',15),(6,'admin',1,'2021-06-15 22:31:19.017000','1234567891-8',18),(7,'admin',3,'2021-06-15 22:33:15.999000','1234567891-4',6),(8,'admin',1,'2021-06-15 22:36:40.599000','1234567891-7',6),(9,'admin',2,'2021-06-16 11:23:39.746000','9787121123320-1',6),(10,'admin',2,'2021-06-16 11:23:39.767000','9787121123320-2',6),(11,'admin',2,'2021-06-16 11:23:39.777000','9787121123320-3',6),(12,'admin',2,'2021-06-16 11:50:52.706000','9787121123320-4',6),(13,'admin',2,'2021-06-16 11:50:52.781000','9787121123320-5',6),(14,'admin',2,'2021-06-16 11:50:52.823000','9787121123320-6',6),(15,'admin',2,'2021-06-16 11:53:47.958000','9787121123320-4',6),(16,'admin',2,'2021-06-16 11:53:47.980000','9787121123320-5',6),(17,'admin',3,'2021-06-16 15:38:29.003000','9787111544937-1',6),(18,'admin',1,'2021-06-25 18:22:09.306000','9780134481265-1',6),(19,'admin',1,'2021-06-25 18:22:09.334000','9780134481265-2',6),(20,'admin',1,'2021-06-25 21:32:18.793000','9787111544937-5',15),(21,'admin',1,'2021-06-25 21:32:45.855000','9787111544937-7',15),(22,'admin',1,'2021-06-25 21:32:45.867000','9787111544937-8',15);
/*!40000 ALTER TABLE `borrow_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `commendid` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` text,
  `deleted_by_admin` bit(1) NOT NULL,
  `deleted_by_self` bit(1) NOT NULL,
  `isbn` varchar(255) DEFAULT NULL,
  `rate` bigint(20) NOT NULL,
  `time` datetime(6) DEFAULT NULL,
  `userid` bigint(20) NOT NULL,
  PRIMARY KEY (`commendid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (1,'好书！',_binary '\0',_binary '\0','1234567891',10,'2021-06-15 22:10:25.763000',6),(2,'希望考试前能预习完',_binary '\0',_binary '','1234567891',0,'2021-06-15 22:34:23.760000',18),(3,'好书，体现了作者的真知灼见！侯老师的翻译也很棒！',_binary '\0',_binary '\0','9787121123320',9,'2021-06-16 12:02:21.474000',6),(4,'这是我们web应用基础课的教材',_binary '\0',_binary '\0','9780134481265',9,'2021-06-25 18:23:47.095000',6),(5,'很棒',_binary '\0',_binary '','9787111544937',8,'2021-06-25 21:39:37.734000',15);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credit_record`
--

DROP TABLE IF EXISTS `credit_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credit_record` (
  `credit_recordid` bigint(20) NOT NULL AUTO_INCREMENT,
  `amount` bigint(20) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `time` datetime(6) DEFAULT NULL,
  `userid` bigint(20) NOT NULL,
  PRIMARY KEY (`credit_recordid`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credit_record`
--

LOCK TABLES `credit_record` WRITE;
/*!40000 ALTER TABLE `credit_record` DISABLE KEYS */;
INSERT INTO `credit_record` VALUES (1,10,'预约图书软件工程1234567891-7超期，降低信用10分','2021-06-15 22:33:56.175000',18),(2,10,'预约图书软件工程1234567891-4超期，降低信用10分','2021-06-15 22:33:56.209000',6),(3,10,'预约图书软件工程1234567891-5超期，降低信用10分','2021-06-15 22:35:29.421000',6),(4,10,'预约图书深入理解计算机系统9787111544937-1超期，降低信用10分','2021-06-15 22:38:47.391000',8),(5,30,'损坏图书Effective C++ 改善程序与设计的55个具体做法9787121123320-2，信用降低30分','2021-06-16 11:24:25.485000',6),(6,40,'损坏图书Effective C++ 改善程序与设计的55个具体做法9787121123320-3，信用降低40','2021-06-16 11:24:25.522000',6),(7,30,'损坏图书Effective C++ 改善程序与设计的55个具体做法9787121123320-4，信用降低30分','2021-06-16 11:54:25.984000',6),(8,40,'丢失图书Effective C++ 改善程序与设计的55个具体做法9787121123320-5，信用降低40','2021-06-16 11:54:26.085000',6),(9,114514,'管理员将您的信用重置为114514','2021-06-16 11:56:30.798000',6),(10,20,'借阅图书深入理解计算机系统9787111544937-1超期，信用降低20分','2021-06-16 15:38:56.967000',6),(11,10,'预约图书软件工程1234567891-8超期，降低信用10分','2021-06-18 08:56:09.752000',21),(12,20,'借阅图书Fundamentals of Web Development (2nd Edition)9780134481265-1超期，信用降低20分','2021-06-25 18:22:40.129000',6),(13,40,'丢失图书Fundamentals of Web Development (2nd Edition)9780134481265-2，信用降低40','2021-06-25 18:22:40.165000',6),(14,30,'损坏图书深入理解计算机系统9787111544937-7，信用降低30分','2021-06-25 21:33:02.736000',15),(15,40,'丢失图书深入理解计算机系统9787111544937-8，信用降低40','2021-06-25 21:33:02.764000',15),(16,10,'预约图书深入理解计算机系统9787111544937-6超期，降低信用10分','2021-06-25 21:36:37.669000',15),(17,20,'借阅图书深入理解计算机系统9787111544937-5超期，信用降低20分','2021-06-25 21:37:52.241000',15),(18,100,'管理员将您的信用重置为100','2021-06-25 21:40:40.826000',15);
/*!40000 ALTER TABLE `credit_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fine`
--

DROP TABLE IF EXISTS `fine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fine` (
  `fineid` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime(6) DEFAULT NULL,
  `money` bigint(20) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `userid` bigint(20) NOT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`fineid`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fine`
--

LOCK TABLES `fine` WRITE;
/*!40000 ALTER TABLE `fine` DISABLE KEYS */;
INSERT INTO `fine` VALUES (13,'2021-06-25 21:33:02.689000',6950,'损坏图书深入理解计算机系统9787111544937-7罚款',15,'17741eed-465d-4dcc-9184-f1898f8a78a2'),(14,'2021-06-25 21:33:02.744000',13900,'丢失图书深入理解计算机系统9787111544937-8罚款',15,'a077addb-3e08-41ae-91c4-53e4c8c9fb2c'),(15,'2021-06-25 21:37:52.208000',3475,'借阅深入理解计算机系统9787111544937-5超期罚款',15,'3175c7d7-3e9e-4d38-87fb-1b01126f66b2');
/*!40000 ALTER TABLE `fine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fine_record`
--

DROP TABLE IF EXISTS `fine_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fine_record` (
  `fine_recordid` bigint(20) NOT NULL AUTO_INCREMENT,
  `money` bigint(20) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `time` datetime(6) DEFAULT NULL,
  `userid` bigint(20) DEFAULT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`fine_recordid`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fine_record`
--

LOCK TABLES `fine_record` WRITE;
/*!40000 ALTER TABLE `fine_record` DISABLE KEYS */;
INSERT INTO `fine_record` VALUES (1,2500,'借阅软件工程1234567891-1损坏罚款','已支付','2021-05-24 12:03:37.135000',6,'aa76385b-4845-4304-a038-700fd3569d18'),(2,2500,'借阅软件工程1234567891-2损坏罚款','已支付','2021-05-24 12:03:37.208000',6,'182ad382-ccf2-4377-a34b-d4fd03f8d8d8'),(3,5000,'借阅软件工程1234567891-3丢失罚款','已支付','2021-05-24 12:03:37.271000',6,'2dabfd1f-950e-471e-b96c-b992721572f3'),(4,2500,'借阅软件工程1234567891-6损坏罚款','已支付','2021-05-24 20:28:57.472000',15,'93e7317c-ae44-4c6f-9d6f-e65a64e9148d'),(5,1250,'借阅软件工程1234567891-7超期罚款','已支付','2021-05-24 20:31:05.584000',15,'5479572d-f5b4-4cf9-8a67-d007118fa4f5'),(6,3250,'借阅Effective C++ 改善程序与设计的55个具体做法9787121123320-2超期罚款','已支付','2021-06-16 11:24:25.444000',6,'2badf129-7608-4ac8-a90b-d4b5a709ed89'),(7,6500,'借阅Effective C++ 改善程序与设计的55个具体做法9787121123320-3超期罚款','已支付','2021-06-16 11:24:25.496000',6,'c336bc40-7d1c-46ef-855c-bf4ffee90c8d'),(8,3250,'损坏图书Effective C++ 改善程序与设计的55个具体做法9787121123320-4罚款','已支付','2021-06-16 11:54:25.900000',6,'aac180c4-5732-4616-8e03-b6d69eb4f6c3'),(9,6500,'丢失图书Effective C++ 改善程序与设计的55个具体做法9787121123320-5罚款','已支付','2021-06-16 11:54:26.019000',6,'9211a40c-1b6c-4409-80a2-de5a40ecdd6c'),(10,3475,'借阅深入理解计算机系统9787111544937-1超期罚款','已支付','2021-06-16 15:38:56.923000',6,'9d865abb-726c-4ca9-861d-68279563ee62'),(11,2862850,'借阅Fundamentals of Web Development (2nd Edition)9780134481265-1超期罚款','已支付','2021-06-25 18:22:40.057000',6,'ef7e2c26-64cf-4753-b39e-30a3f93ccd96'),(12,11451400,'丢失图书Fundamentals of Web Development (2nd Edition)9780134481265-2罚款','已支付','2021-06-25 18:22:40.139000',6,'3f92abc9-2c32-4607-ba6a-2f620ed0b057'),(13,6950,'损坏图书深入理解计算机系统9787111544937-7罚款','未支付','2021-06-25 21:33:02.689000',15,'17741eed-465d-4dcc-9184-f1898f8a78a2'),(14,13900,'丢失图书深入理解计算机系统9787111544937-8罚款','未支付','2021-06-25 21:33:02.744000',15,'a077addb-3e08-41ae-91c4-53e4c8c9fb2c'),(15,3475,'借阅深入理解计算机系统9787111544937-5超期罚款','未支付','2021-06-25 21:37:52.208000',15,'3175c7d7-3e9e-4d38-87fb-1b01126f66b2');
/*!40000 ALTER TABLE `fine_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `library`
--

DROP TABLE IF EXISTS `library`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `library` (
  `libraryid` bigint(20) NOT NULL AUTO_INCREMENT,
  `library_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`libraryid`),
  UNIQUE KEY `UK_6jj7g870fs607y0b7s5avdf7y` (`library_name`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `library`
--

LOCK TABLES `library` WRITE;
/*!40000 ALTER TABLE `library` DISABLE KEYS */;
INSERT INTO `library` VALUES (3,'张江校区图书馆'),(2,'枫林校区图书馆'),(4,'江湾校区图书馆'),(1,'邯郸校区图书馆');
/*!40000 ALTER TABLE `library` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reply`
--

DROP TABLE IF EXISTS `reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reply` (
  `replyid` bigint(20) NOT NULL AUTO_INCREMENT,
  `commentid` bigint(20) NOT NULL,
  `content` text,
  `deleted_by_admin` bit(1) NOT NULL,
  `deleted_by_self` bit(1) NOT NULL,
  `replied_userid` bigint(20) NOT NULL,
  `time` datetime(6) DEFAULT NULL,
  `userid` bigint(20) NOT NULL,
  PRIMARY KEY (`replyid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reply`
--

LOCK TABLES `reply` WRITE;
/*!40000 ALTER TABLE `reply` DISABLE KEYS */;
INSERT INTO `reply` VALUES (1,1,'六四',_binary '\0',_binary '',6,'2021-06-15 22:10:30.904000',6),(2,1,'是我学不来的东西',_binary '\0',_binary '\0',6,'2021-06-15 22:25:29.023000',8),(3,1,'希望考试前能预习完',_binary '',_binary '\0',8,'2021-06-15 22:36:57.516000',18),(4,1,'我还没打开过这本书呢',_binary '\0',_binary '\0',18,'2021-06-15 22:56:44.127000',6),(5,3,'喵喵喵',_binary '',_binary '\0',6,'2021-06-16 12:02:44.138000',6),(6,1,'傻 逼',_binary '\0',_binary '',6,'2021-06-16 21:49:47.313000',20),(7,1,'000',_binary '\0',_binary '',6,'2021-06-17 21:26:18.127000',18),(8,1,'哈哈哈哈',_binary '',_binary '\0',6,'2021-06-23 14:54:36.334000',6),(9,4,'虽然书很厚，但是由浅入深，讲得很易懂，但是深度不足，需要再补充另外的材料。',_binary '\0',_binary '\0',6,'2021-06-25 18:24:25.789000',6);
/*!40000 ALTER TABLE `reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservation` (
  `reservationid` bigint(20) NOT NULL AUTO_INCREMENT,
  `book_copyid` bigint(20) DEFAULT NULL,
  `deadline` datetime(6) DEFAULT NULL,
  `reservation_date` datetime(6) DEFAULT NULL,
  `userid` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`reservationid`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reserve_record`
--

DROP TABLE IF EXISTS `reserve_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reserve_record` (
  `reserve_recordid` bigint(20) NOT NULL AUTO_INCREMENT,
  `admin` varchar(255) DEFAULT NULL,
  `libraryid` bigint(20) NOT NULL,
  `time` datetime(6) DEFAULT NULL,
  `unique_book_mark` varchar(255) DEFAULT NULL,
  `userid` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`reserve_recordid`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reserve_record`
--

LOCK TABLES `reserve_record` WRITE;
/*!40000 ALTER TABLE `reserve_record` DISABLE KEYS */;
INSERT INTO `reserve_record` VALUES (1,'admin',1,'2021-05-23 23:44:52.038000','1234567891-1',6),(2,'admin',1,'2021-05-23 23:54:07.651000','1234567891-2',6),(3,'admin',1,'2021-05-24 11:53:00.718000','1234567891-3',6),(4,'admin',1,'2021-05-24 11:56:32.587000','9787111544937-1',6),(5,'admin',1,'2021-05-24 11:56:33.714000','9787111544937-2',6),(6,'admin',1,'2021-05-24 11:56:34.961000','9787111544937-3',6),(7,'admin',1,'2021-05-24 11:56:39.489000','1234567891-2',6),(8,'admin',1,'2021-05-24 20:26:48.273000','1234567891-6',15),(9,'admin',1,'2021-05-24 20:26:49.849000','1234567891-7',15),(10,'admin',1,'2021-05-24 20:26:50.880000','1234567891-8',15),(11,'admin',1,'2021-05-24 20:26:51.926000','1234567891-5',15),(12,'admin',1,'2021-05-24 20:26:54.591000','1234567891-4',15),(13,'admin',1,'2021-06-15 22:24:00.337000','1234567891-7',18),(14,'admin',1,'2021-06-15 22:30:49.119000','1234567891-8',18),(15,'admin',1,'2021-06-15 22:31:58.240000','1234567891-4',6),(16,'admin',1,'2021-06-15 22:33:36.664000','1234567891-4',6),(17,'admin',1,'2021-06-15 22:35:11.550000','1234567891-5',6),(18,'admin',1,'2021-06-15 22:37:01.069000','9787111544937-1',8),(19,'admin',1,'2021-06-17 00:57:54.997000','1234567891-8',21),(20,'admin',1,'2021-06-25 21:32:01.231000','9787111544937-5',15),(21,'admin',1,'2021-06-25 21:32:02.846000','9787111544937-6',15);
/*!40000 ALTER TABLE `reserve_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `return_record`
--

DROP TABLE IF EXISTS `return_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `return_record` (
  `return_recordid` bigint(20) NOT NULL AUTO_INCREMENT,
  `admin` varchar(255) DEFAULT NULL,
  `libraryid` bigint(20) NOT NULL,
  `time` datetime(6) DEFAULT NULL,
  `unique_book_mark` varchar(255) DEFAULT NULL,
  `userid` bigint(20) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`return_recordid`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `return_record`
--

LOCK TABLES `return_record` WRITE;
/*!40000 ALTER TABLE `return_record` DISABLE KEYS */;
INSERT INTO `return_record` VALUES (1,'admin',1,'2021-05-24 12:03:37.135000','1234567891-1',6,'ok'),(2,'admin',1,'2021-05-24 12:03:37.208000','1234567891-2',6,'ok'),(3,'admin',1,'2021-05-24 12:03:37.271000','1234567891-3',6,'ok'),(4,'admin',1,'2021-05-24 20:28:57.472000','1234567891-6',15,'ok'),(5,'admin',1,'2021-05-24 20:31:05.584000','1234567891-7',15,'ok'),(6,'admin',3,'2021-06-15 22:33:25.781000','1234567891-4',6,'ok'),(7,'admin',1,'2021-06-15 22:33:29.554000','1234567891-8',18,'ok'),(8,'admin',2,'2021-06-16 11:24:25.422000','9787121123320-1',6,'ok'),(9,'admin',2,'2021-06-16 11:24:25.444000','9787121123320-2',6,'damaged'),(10,'admin',2,'2021-06-16 11:24:25.496000','9787121123320-3',6,'lost'),(11,'admin',2,'2021-06-16 11:53:00.029000','9787121123320-4',6,'ok'),(12,'admin',2,'2021-06-16 11:53:00.129000','9787121123320-5',6,'ok'),(13,'admin',2,'2021-06-16 11:53:00.180000','9787121123320-6',6,'ok'),(14,'admin',2,'2021-06-16 11:54:25.900000','9787121123320-4',6,'damaged'),(15,'admin',2,'2021-06-16 11:54:26.019000','9787121123320-5',6,'lost'),(16,'admin',2,'2021-06-16 11:55:32.265000','1234567891-7',6,'ok'),(17,'admin',3,'2021-06-16 15:38:56.923000','9787111544937-1',6,'ok'),(18,'admin',1,'2021-06-25 18:22:40.057000','9780134481265-1',6,'ok'),(19,'admin',1,'2021-06-25 18:22:40.139000','9780134481265-2',6,'lost'),(20,'admin',1,'2021-06-25 21:33:02.689000','9787111544937-7',15,'damaged'),(21,'admin',1,'2021-06-25 21:33:02.744000','9787111544937-8',15,'lost'),(22,'admin',1,'2021-06-25 21:37:52.208000','9787111544937-5',15,'ok');
/*!40000 ALTER TABLE `return_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `credit` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `UK_sb8bbouer5wak8vyiiy4pf2bx` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,100,'admin@admin.com','admin','superadmin','admin'),(6,114434,'19302010021@fudan.edu.cn','Zhj001006','undergraduate','19302010021'),(7,100,'zhj63095214@gmail.com','Zhj001006','admin','zhanghaojie'),(8,90,'19302010075@fudan.edu.cn','IamElaine1908','undergraduate','19302010075'),(15,100,'20212010040@fudan.edu.cn','fdse123123','postgraduate','20212010040'),(18,90,'18300120031@fudan.edu.cn','123456789a','undergraduate','18300120031'),(20,100,'19302010069@fudan.edu.cn','001128Xy','undergraduate','19302010069'),(21,90,'19302010084@fudan.edu.cn','Zhj001006','undergraduate','19302010084');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_configuration`
--

DROP TABLE IF EXISTS `user_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_configuration` (
  `user_configurationid` bigint(20) NOT NULL AUTO_INCREMENT,
  `max_book_borrow` bigint(20) NOT NULL,
  `max_borrow_time` bigint(20) NOT NULL,
  `max_reserve_time` bigint(20) NOT NULL,
  `role` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_configurationid`),
  UNIQUE KEY `UK_44cnw3g9a53nl9mpt0875fhip` (`role`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_configuration`
--

LOCK TABLES `user_configuration` WRITE;
/*!40000 ALTER TABLE `user_configuration` DISABLE KEYS */;
INSERT INTO `user_configuration` VALUES (1,114514,9894051915,9894051914,'teacher'),(2,3,1,1,'undergraduate'),(3,100,120,120,'postgraduate');
/*!40000 ALTER TABLE `user_configuration` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-27  0:43:15
